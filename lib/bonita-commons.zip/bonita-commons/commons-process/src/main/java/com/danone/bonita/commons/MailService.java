package com.danone.bonita.commons;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MailService.class);
	
	public static void senMail(String to, String subject, String body) {
		
		String from = PropertiesLoader.getMailSender();
		String host = PropertiesLoader.getMailServer();
		Integer port = PropertiesLoader.getMailPort();

		// Get the session object
		Properties properties = new Properties();
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", port);
		properties.put("mail.smtp.auth", true);
		Authenticator authenticator = null;
	    authenticator = new Authenticator() {
	        private PasswordAuthentication pa = new PasswordAuthentication(PropertiesLoader.getMailServerUsername(), PropertiesLoader.getMailServerPassword());
	        @Override
	        public PasswordAuthentication getPasswordAuthentication() {
	            return pa;
	        }
	    };
	    
	    Session session = Session.getInstance(properties, authenticator);

		// compose the message
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject(subject);
			message.setContent(body, "text/html; charset=utf-8");

			// Send message
			Transport.send(message);

		} catch (MessagingException mex) {
			LOGGER.error(mex.getMessage(), mex);
		}
	}
}
