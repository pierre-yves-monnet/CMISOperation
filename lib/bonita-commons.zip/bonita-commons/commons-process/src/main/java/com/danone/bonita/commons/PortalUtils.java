package com.danone.bonita.commons;

import jp.co.danone.bpm.bdm.DocumentToReview;

/**
 * Class used to generate informations to display in the portal
 * @author glethiec
 *
 */
public final class PortalUtils {

	/*
	 * Static class so no public constructor
	 */
	private PortalUtils(){}
	
	/**
	 * generate task name from step and doc values
	 * @param step the step to use in the name
	 * @param docToReview the document concern by this step
	 * @return task label to display in the portal
	 */
	public static String getTaskName(String step, DocumentToReview docToReview){

		String name = docToReview.getDProps().getCmis_name();

		return step + " " + name;
	}

	/**
	 * generate task description from step and doc values
	 * @param step the step to use in the name
	 * @param docToReview the document concern by this step
	 * @return task label to display in the portal
	 */
	public static String getTaskDescription(String step, DocumentToReview docToReview){

		String docOnwer = docToReview.getDProps().getDanoneBpms_documentOwner();
		if (docOnwer == null || docOnwer.isEmpty()) {
			docOnwer = "Unknown";
		}
		return "Document owner: " + docOnwer;
	}

}
