package com.danone.bonita.commons;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bonitasoft.engine.api.APIAccessor;
import org.bonitasoft.engine.bpm.flownode.ActivityInstance;
import org.bonitasoft.engine.bpm.flownode.ActivityStates;
import org.bonitasoft.engine.bpm.flownode.FlowNodeType;
import org.bonitasoft.engine.bpm.process.ProcessInstanceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.danone.bpm.bdm.DocumentToReview;

/**
 * Class used to load email to be used in the workflow and change variables
 *
 * @author glethiec
 */
public final class MailsUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MailsUtil.class);
	
	
	/*
	 * Static class so no public constructor
	 */
	private MailsUtil(){}
	
	/**
	 * 
	 * @param mailId the property id of the mail to generate
	 * @param doc the doctoreview object from bonita
	 */
	public static String getSubject(String mailId, DocumentToReview doc){

		String docTitle = doc.getDProps().getCmis_name();
		
		return getSubjectMail(mailId, docTitle);
	}
	
	/**
	 * 
	 * @param mailId the property id of the mail to generate
	 * @param duedateId the property id of the duedate timer for this task
	 * @param apiAccessor bonita apiaccessoir
	 * @param doc the doctoreview object from bonita
	 * @param actor the username od the actor of the task
	 * @param processId the id of the current process
	 * @param subprocessId the id of the current subProcess
	 * @param taskId the id of the task
	 * @return the html mail as a string
	 */
	public static String getBody(String mailId, String duedateId, APIAccessor apiAccessor, DocumentToReview doc, String actor, Long processId, Long subprocessId, Long taskId){
		
		String userDisplay = UserUtil.getUserDisplayNameFromUserName(apiAccessor, actor);
		Date date = null;
		try {
			date = apiAccessor.getProcessAPI().getProcessInstance(subprocessId).getStartDate();
		} catch (ProcessInstanceNotFoundException e) {
			LOGGER.error(e.getMessage(), e);
		}
		String docOwner = doc.getDProps().getDanoneBpms_documentOwner();
		String docOwnerDisplayName = UserUtil.getUserDisplayNameFromUserName(apiAccessor, docOwner);
		String docTitle = doc.getDProps().getCmis_name();
		//GetActivities need the parent process, if subprocess id is used there is no task.
		List<ActivityInstance> activities = apiAccessor.getProcessAPI().getActivities(processId, 0, 1000);

		Long usertaskId = taskId;
		for (ActivityInstance acti : activities){
			//to find the good task in the subprocess wich check status task id and the subprocess id.
			if ((acti.getState().equals(ActivityStates.READY_STATE)||acti.getState().equals(ActivityStates.INITIALIZING_STATE)) && acti.getId() != taskId && acti.getParentContainerId() == subprocessId){
				usertaskId = acti.getId();
			}
		}
		
		return getBodyMail(mailId, duedateId, docTitle, docOwnerDisplayName, userDisplay, date, usertaskId);
	}


	/**
	 * Gets user task id.
	 *
	 * @param apiAccessor  the api accessor
	 * @param processId    the process id
	 * @param subprocessId the subprocess id
	 * @param taskId       the task id
	 * @return the user task id
	 */
	public static Long getUserTaskId(APIAccessor apiAccessor, Long processId, Long subprocessId, Long taskId) {
		List<ActivityInstance> activities = apiAccessor.getProcessAPI().getActivities(processId, 0, 1000);

		Long usertaskId = taskId;
		for (ActivityInstance acti : activities){
			//to find the good task in the subprocess wich check status task id and the subprocess id.
			if ((acti.getState().equals(ActivityStates.READY_STATE)||acti.getState().equals(ActivityStates.INITIALIZING_STATE)) && FlowNodeType.USER_TASK.equals(acti.getType()) && acti.getParentContainerId() == subprocessId){
				usertaskId = acti.getId();
			}
		}
		return usertaskId;
	}

	public static String getSubjectMail(String mailId, String docTitle){
		
		String subject = PropertiesLoader.getProperty(mailId);	
		subject = subject.replace("{docTitle}", docTitle);
				
		return subject;
	}
	
	public static String getBodyMail(String mailId, String duedateId, String docTitle, String docOwner, String userDisplay, Date date, Long usertaskId){

		Map<String, Serializable> param = new HashMap<>();
		param.put("displayName", userDisplay);
		param.put("docTitle", docTitle);
		if (docOwner == null || "".equals(docOwner)){
			docOwner = "Unknown";
		}
		param.put("docOwner", docOwner);

		String dueDate = getDueDate(duedateId, date);

		param.put("dueDate", dueDate);
		
		String link = PropertiesLoader.getProperty("bonitaurl")+"portal/homepage#?id="+usertaskId+"&_p=performTask&_pf=1";
		param.put("link", link);

		return getBodyMail(mailId, param);
	}

	public static String getDueDate(String duedateId, Date startDate) {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(startDate);
		Integer duedateTimer = Integer.parseInt(PropertiesLoader.getProperty(duedateId));
		cal.add(Calendar.MILLISECOND, duedateTimer);
		int month = cal.get(Calendar.MONTH)+1;
		return cal.get(Calendar.DAY_OF_MONTH) + "/" + month + "/" + cal.get(Calendar.YEAR);
	}

	public static String getBodyMail(String mailId, Map<String, Serializable> param) {

		String body = PropertiesLoader.getProperty(mailId);

		for (Map.Entry<String, Serializable> entry : param.entrySet()) {
			Serializable value = entry.getValue();
			if (value == null) {
				value = "";
			}
			body = body.replace("{" + entry.getKey() + "}", value.toString());
		}

		return body;
	}
}