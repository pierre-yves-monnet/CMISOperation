package com.danone.bonita.commons;

import java.util.Map;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.bonita.to.BpmsState;
import com.danone.bonita.to.BpmsStep;
import com.danone.bonita.to.WorkflowInformation;
import com.danone.bonita.to.WorkflowTaskInformation;
import com.google.gson.Gson;

import jp.co.danone.bpm.bdm.DocumentToReview;

public class DandocUtils {

	private static final String URL_START_WF = PropertiesLoader.getAlfrescoApp() + PropertiesLoader.getProperty("wsStartWF");
	private static final String URL_END_WF = PropertiesLoader.getAlfrescoApp() + PropertiesLoader.getProperty("wsEndWF");

	private static final String URL_START_TASK_WF = PropertiesLoader.getAlfrescoApp() + PropertiesLoader.getProperty("wsStartTaskWF");
	private static final String URL_END_TASK_WF = PropertiesLoader.getAlfrescoApp() + PropertiesLoader.getProperty("wsEndTaskWF");

	private static final Logger LOGGER = LoggerFactory.getLogger(DandocUtils.class);

	public static void startWorkflow(Long idWorkflow, String typeWorkflow, DocumentToReview workingDoc, DocumentToReview originalDoc, String comment){
		LOGGER.debug("Start Workflow : {}", idWorkflow);
		String workingDocId = workingDoc.getId();
		String originalDocId = (originalDoc != null) ? originalDoc.getId() : null;
		String documentOwner = workingDoc.getDProps().getDanoneBpms_documentOwner();
		startWorkflow(idWorkflow, typeWorkflow, workingDocId, originalDocId, documentOwner, comment);
	}

	public static void startWorkflow(Long idWorkflow, String typeWorkflow, String workingDocId, String originalDocId, String documentOwner, String comment) {
		LOGGER.debug("Start Workflow : {}", idWorkflow);

		WorkflowInformation info = new WorkflowInformation();
		info.setIdWorkflow(idWorkflow);
		info.setTypeWorkflow(typeWorkflow);
		info.setWorkingDocument(workingDocId);
		info.setOriginalDocument(originalDocId);
		info.setDocumentOwner(documentOwner);
		info.setState(BpmsState.INIT);
		info.setComment(comment);

		RestUtils.postWS(URL_START_WF, new Gson().toJson(info), PropertiesLoader.getProperty("alfrescologin"));
	}

	public static String endWorkflow(Long idWorkflow, String typeWorkflow, DocumentToReview workingDoc, DocumentToReview originalDoc, boolean success, String comment){
		LOGGER.debug("End Workflow : {}", idWorkflow);
		String workingDocId = workingDoc.getId();
		String originalDocId = (originalDoc != null) ? originalDoc.getId() : null;
		return endWorkflow(idWorkflow, typeWorkflow, workingDocId, originalDocId, success, comment);

	}

	public static String endWorkflow(Long idWorkflow, String typeWorkflow, String workingDocId, String originalDocId, boolean success, String comment) {
		LOGGER.debug("End Workflow : {}", idWorkflow);
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();

		WorkflowInformation info = new WorkflowInformation();
		info.setIdWorkflow(idWorkflow);
		info.setTypeWorkflow(typeWorkflow);
		info.setWorkingDocument(workingDocId);
		info.setOriginalDocument(originalDocId);
		
		info.setIssueDate(dateFormat.format(date));
		
		if (success){
			info.setState(BpmsState.SUCCESS);
		}else{
			info.setState(BpmsState.REJECT);
		}
		info.setComment(comment);

		Map<String, String> response = RestUtils.postWS(URL_END_WF, new Gson().toJson(info), PropertiesLoader.getProperty("alfrescologin"));
		return response.get(RestUtils.RESPONSE_MESSAGE);
	}

	public static String startTask(Long idWorkflow, Long idTask, String workingDocId, String actor, BpmsStep step, String comment, String access) {
		LOGGER.debug("Start Task Workflow : {}", idTask);


		WorkflowTaskInformation info = new WorkflowTaskInformation();
		info.setIdWorkflow(idWorkflow);
		info.setIdWorkflowTask(idTask);
		info.setWorkingDocument(workingDocId);
		info.setActor(actor);
		info.setStep(step);
		info.setState(BpmsState.INIT);
		info.setComment(comment);
		info.setAccess(access);

		Map<String, String> response = RestUtils.postWS(URL_START_TASK_WF, new Gson().toJson(info), PropertiesLoader.getProperty("alfrescologin"));
		LOGGER.debug("doc id: "+response.get(RestUtils.RESPONSE_MESSAGE));
		return response.get(RestUtils.RESPONSE_MESSAGE);
	}

	public static String endTask(Long idWorkflow, Long idTask, String workingDocId, String actor, BpmsStep step, BpmsState state, String comment, String access) {
		LOGGER.debug("End Task Workflow : {}", idTask);

		WorkflowTaskInformation info = new WorkflowTaskInformation();
		info.setIdWorkflow(idWorkflow);
		info.setIdWorkflowTask(idTask);
		info.setWorkingDocument(workingDocId);
		info.setActor(actor);
		info.setStep(step);
		info.setState(state);
		info.setComment(comment);
		info.setAccess(access);

		Map<String, String> response = RestUtils.postWS(URL_END_TASK_WF, new Gson().toJson(info), PropertiesLoader.getProperty("alfrescologin"));
		LOGGER.debug("doc id: "+response.get(RestUtils.RESPONSE_MESSAGE));
		return response.get(RestUtils.RESPONSE_MESSAGE);
	}
}
