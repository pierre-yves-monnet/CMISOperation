package com.danone.bonita.to;

public enum BpmsState {
	INIT,
	SUCCESS,
	REJECT,
	UNASSIGN
}
