package com.danone.bonita.to;

public enum BpmsStep {
	START,
	VALIDATION,
	APPROVAL,
	SIGNATURE,
	REVIEW,
	FINISHREVIEW,
	NOTIFREJECT,
	DELETE,
	END

}