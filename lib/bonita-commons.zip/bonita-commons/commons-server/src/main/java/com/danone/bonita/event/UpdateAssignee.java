package com.danone.bonita.event;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.UUID;

import org.bonitasoft.engine.commons.exceptions.SBonitaException;
import org.bonitasoft.engine.core.process.instance.api.exceptions.SActivityInstanceNotFoundException;
import org.bonitasoft.engine.core.process.instance.api.exceptions.SActivityReadException;
import org.bonitasoft.engine.core.process.instance.model.SFlowNodeInstance;
import org.bonitasoft.engine.core.process.instance.model.SHumanTaskInstance;
import org.bonitasoft.engine.data.instance.api.DataInstanceContainer;
import org.bonitasoft.engine.data.instance.api.DataInstanceService;
import org.bonitasoft.engine.data.instance.exception.SDataInstanceNotFoundException;
import org.bonitasoft.engine.data.instance.model.SDataInstance;
import org.bonitasoft.engine.events.model.SEvent;
import org.bonitasoft.engine.events.model.SHandler;
import org.bonitasoft.engine.events.model.SHandlerExecutionException;
import org.bonitasoft.engine.identity.IdentityService;
import org.bonitasoft.engine.identity.SUserNotFoundException;
import org.bonitasoft.engine.identity.model.SUser;
import org.bonitasoft.engine.recorder.model.EntityUpdateDescriptor;
import org.bonitasoft.engine.service.TenantServiceAccessor;
import org.bonitasoft.engine.service.impl.ServiceAccessorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.danone.bonita.commons.PropertiesLoader;
import com.danone.bonita.commons.RestUtils;
import com.danone.bonita.to.BpmsState;
import com.danone.bonita.to.BpmsStep;
import com.danone.bonita.to.WorkflowTaskInformation;
import com.google.gson.Gson;

public class UpdateAssignee implements SHandler<SEvent> {

	/**
	 *
	 */
	private static final long serialVersionUID = 2114410708865804273L;

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAssignee.class);

	private long tenantId;

	private static final String URL_UPDATE_ASSIGNEE = PropertiesLoader.getAlfrescoApp() + PropertiesLoader.getProperty("wsUpdateAssignee");
	
	public UpdateAssignee(final long tenantId) {
		super();
		this.tenantId = tenantId;
	}

	@Override
	public void execute(SEvent event) throws SHandlerExecutionException {

		TenantServiceAccessor tenantServiceAccessor = getTenantServiceAccessor();
		IdentityService identityService = tenantServiceAccessor.getIdentityService();
		SFlowNodeInstance flowNodeInstance = (SFlowNodeInstance) event.getObject();

		try {
			//get the current User task
			SHumanTaskInstance userTask = tenantServiceAccessor.getActivityInstanceService().getHumanTaskInstance(flowNodeInstance.getId());

			DataInstanceService dataInstanceService = tenantServiceAccessor.getDataInstanceService();

			//get the actor previously assigned to this task
			SDataInstance actor;
			actor = dataInstanceService.getDataInstance("actor", userTask.getId(), DataInstanceContainer.ACTIVITY_INSTANCE.name(), tenantServiceAccessor.getParentContainerResolver());
			
			//get the new assignee
			SUser user = identityService.getUser(userTask.getAssigneeId());
			String assignee = user.getUserName();

			//if the task as been really reassign to a new actor
			if (!actor.getValue().equals(assignee)){
				//set the new value of Actor
				EntityUpdateDescriptor descriptor = new EntityUpdateDescriptor();
				descriptor.addField("value", assignee);
				dataInstanceService.updateDataInstance(actor, descriptor);
				
				Long idWorkflow = userTask.getRootProcessInstanceId();
				Long idTask = userTask.getParentProcessInstanceId();
				SDataInstance docIdData = dataInstanceService.getDataInstance("docId", userTask.getId(), DataInstanceContainer.ACTIVITY_INSTANCE.name(), tenantServiceAccessor.getParentContainerResolver());
				String workingDocId = docIdData.getValue().toString();
				//notifier Alfresco du changement
				updateTask(idWorkflow, idTask, workingDocId, assignee, null, null);
			}
		} catch (SDataInstanceNotFoundException e){
			LOGGER.warn("The variable <actor> doesn't exist, handler is not needed.");
		} catch (SBonitaException e) {
			LOGGER.error(e.getMessage(), e);
		}

	}

	@Override
	public String getIdentifier() {
		// ensure this handler is registered only once
		return UUID.randomUUID().toString();
	}

	@Override
	public boolean isInterested(SEvent event) {
		boolean isInterested = false;
		SFlowNodeInstance flowNodeInstance = (SFlowNodeInstance) event.getObject();
		try {
			// get the assigneeId
			TenantServiceAccessor tenantServiceAccessor = getTenantServiceAccessor();
			long userId = tenantServiceAccessor.getActivityInstanceService()
					.getHumanTaskInstance(flowNodeInstance.getId()).getAssigneeId();
			// if it's assign action and not unassign
			if (userId != 0) {
				// does the user exist
				tenantServiceAccessor.getIdentityService().getUser(userId);
				isInterested = true;
			}
		} catch (SActivityReadException | SActivityInstanceNotFoundException | SHandlerExecutionException
				| SUserNotFoundException e) {
			LOGGER.error("Impossible to treat the assignation", e);
		}
		return isInterested;
	}

	private TenantServiceAccessor getTenantServiceAccessor() throws SHandlerExecutionException {
		try {
			return ServiceAccessorFactory.getInstance().createTenantServiceAccessor(tenantId);
		} catch (final Exception e) {
			LOGGER.error(e.getMessage() ,e);
			throw new SHandlerExecutionException(e.getMessage(), null);
		}
	}

	public static String updateTask(Long idWorkflow, Long idTask, String workingDocId, String actor, BpmsStep step, String comment) {
		LOGGER.debug("Start Task Workflow : {}", idTask);


		WorkflowTaskInformation info = new WorkflowTaskInformation();
		info.setIdWorkflow(idWorkflow);
		info.setIdWorkflowTask(idTask);
		info.setWorkingDocument(workingDocId);
		info.setActor(actor);
		info.setStep(step);
		info.setState(BpmsState.UNASSIGN);
		info.setComment(comment);

		Map<String, String> response = RestUtils.postWS(URL_UPDATE_ASSIGNEE, new Gson().toJson(info), PropertiesLoader.getProperty("alfrescologin"));
		LOGGER.debug("doc id: "+response.get(RestUtils.RESPONSE_MESSAGE));
		return response.get(RestUtils.RESPONSE_MESSAGE);
	}
	
	public static Object runGetter(String field, Object o){
	    // Find the correct method
	    for (Method method : o.getClass().getMethods()){
	        if (((method.getName().startsWith("get")) && (method.getName().length() == (field.length() + 3))) && method.getName().toLowerCase().endsWith(field.toLowerCase())){
	            try {// Method found, run it
	            	return method.invoke(o);
	            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
	            	LOGGER.error(e.getMessage(), e);
	            }
	        }
	    }
	    return null;
	}
}
